/*
 * systemClock.h
 *
 *  Created on: 31 mars 2016
 *      Author: kerhoas
 */

#ifndef INC_SYSTEMCLOCK_H_
#define INC_SYSTEMCLOCK_H_

#include "main.h"

void systemClock_Config(void);



#endif /* INC_SYSTEMCLOCK_H_ */
